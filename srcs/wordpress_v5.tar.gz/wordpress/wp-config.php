<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'wp_database' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'wp_user' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', 'wp_passwd' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '+voBW|6faa<3U-3uTWsy]n+!zf*b(;|(4NPU.Pu(}^oZl|W,[u`7b]W0TY-(/qH0');
define('SECURE_AUTH_KEY',  'o)1@iF*g&yK+[[J6uESfkboMM?+$GIJ`;|7V9z|D,y5I?KGSvC,X*{7p@n5ZwCn+');
define('LOGGED_IN_KEY',    '1DrP*F?V#k4k$z-!7utGF=g|I1S=!Z$u8|Q&FLYIX/+Z~<Oq5c/k2/ia5=5|xNy7');
define('NONCE_KEY',        '*;~h # vdWBKOka~tv-N@LZKTP(x4o&}{(D=b{I1w^s(e}}*y |d]I.6X<bQJ@+V');
define('AUTH_SALT',        'uSlKvs+r&rqF06<%g-n7Af&@+OB#o32%|{cr8!O;-ywKRwT1Bf!K+zEt~Ckd;>I=');
define('SECURE_AUTH_SALT', 'z#=I~1</?2$|$3w5Uh+K9|X|v_q=OS^u7N}&ip=% &`ex[F|GyVqeM]^k:KU2Pab');
define('LOGGED_IN_SALT',   'CUcY7+<`|c=h^loQ$O@BgUUzU4y~pt/VUF{$9s?|wLH]~l*2yz$SR/&(e@c4 E6Z');
define('NONCE_SALT',       '.3lz4!VVR@I|C?/iz`&e?v t9^-XL$9a9S[-#JHGwd@$@-T.T[QP@JUogF$if0)z');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
